require("testrail-api");
require("dotenv").config();
testrailresult = async function (surl)
{
console.log(surl);
const Testrail = require("testrail-api");

const testrail = new Testrail({
  host: process.env.TESTRAIL_HOST,
  user: process.env.TESTRAIL_USER,
  password: process.env.TESTRAIL_API_KEY,
});

const date = new Date();
const testRailCaseId = 202;
const testRailProjectId = 1;
 
    try{
        console.log("inside main function")
  // Case Steps from Testrail
  var lurl=surl;
  console.log(lurl);
  const cases = await testrail.getCase(1);
  const caseSteps = cases.body.custom_steps_separated;
  console.log(caseSteps);
  // Add actual and status_id props
  const results = await caseSteps.map((step) => ({
    ...step,
    actual: "",
    status_id: 5,
  }));
  console.log(results);

  // Start Test Rail Run
  await testrail.addRun(
    testRailProjectId,
    { name: `Automation test on: ${date}` },
    async function (err, response, run) {
      let testRailRunId = run.id;
      console.log(testRailRunId);
      console.log(testRailCaseId);

      // Add Results (This is where we want LambdaTest results including screenshots)
      await testrail.addResultForCase(testRailRunId, testRailCaseId, {
        status_id: 1,
        comment: lurl,
        results:results,
      });
      await testrail.closeRun(testRailRunId, function (err, response, run) {
        console.log("Run", run);
      });
    }
  );}
  catch(e){

  }
}

//testRuns();
module.exports= {testrailresult};