
ltscreenshot = async function (session_id) {

    try{
      console.log("in");
      var request = require('request');
      const tr = require('./testrail');
      
      var sid=session_id;
      var options = {
        'method': 'GET',
        'url': 'https://api.lambdatest.com/automation/api/v1/sessions/'+sid+'/screenshots',
        'headers': {
          'Authorization': 'Basic bXVkYXNzYXJzOkdpZ1I3NkRsMEhJbFNKVHE3eHJDS2VQVk9FYzlKMU9YME4zQ09saDkwenpmSXg1MXVp'
        }
      };
      await request(options, function (error, response) {
        if (error) throw new Error(error);
        response1 = JSON.parse(response.body);
        console.log("Screenshot url:"+response1.url);
        tr.testrailresult(response1.url);
      });

  }
  catch (err) {
    console.log(err);
  };
  return response1;
};
module.exports = { ltscreenshot }

//ltscreenshot()